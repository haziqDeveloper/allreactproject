/** @format */

import { Navigate, useRoutes } from "react-router-dom";
// layouts
import DashboardLayout from "./layouts/dashboard";
import LogoOnlyLayout from "./layouts/LogoOnlyLayout";
//
import Login from "./pages/Auth/Login";

// Role CRUD
import AddEditRole from "./pages/Role_Management/AddEditRole";
import PlatinumAddEditRole from "./pages/KingPlatinum/Role_Management/AddEditRole";
import RoleList from "./pages/Role_Management/RoleList";
import PlatinumRoleList from "./pages/KingPlatinum/Role_Management/RoleList";
import ProductPriceList from "./pages/Product_Price_Management/ProductPriceList";
import AddEditProduct from "./pages/Product_Price_Management/AddEditProduct";
import DOMAINURL from "./pages/DomainUrl";
import APPINFO from "./pages/KingPlatinum/DomainUrl";
import PLATINUMCONTACTDETAIL from "./pages/KingPlatinum/ContactDetail";
import CONTACTDETAIL from "./pages/ContactDetail";
import UPDATEVERSION from "./pages/UpdateVersion";
import NotFound from "./pages/Page404";
import Protected from "./components/Protected";


// ----------------------------------------------------------------------

export default function Router() {
	return useRoutes([
		{
			path: "/",
			element: <Login />,
		},
		{
			path: "/",
			element: <Protected Component={Login} />,
		},
		{
			path: "/",
			element: <DashboardLayout />,
			children: [
				{ path: "device-info", element: <Protected Component={RoleList} /> },
				{
					path: "add-role-list",
					element: <Protected Component={AddEditRole} />,
				},
				{
					path: "device-info-note/:id",
					element: <Protected Component={AddEditRole} />,
				},
				{ path: "platinum-device-info", element: <Protected Component={PlatinumRoleList} /> },
				{
					path: "add-role-list",
					element: <Protected Component={AddEditRole} />,
				},
				{
					path: "platinum-device-info-note/:id",
					element: <Protected Component={PlatinumAddEditRole} />,
				},
				{
					path: "portal-list",
					element: <Protected Component={ProductPriceList} />,
				},
				{
					path: "add-portal",
					element: <Protected Component={AddEditProduct} />,
				},
				{
					path: "edit-portal/:id",
					element: <Protected Component={AddEditProduct} />,
				},
				{
					path: "app_info",
					element: <Protected Component={DOMAINURL} />,
				},
				{
					path: "contact_detail",
					element: <Protected Component={CONTACTDETAIL} />,
				},
				{
					path: "platinum_app_info",
					element: <Protected Component={APPINFO} />,
				},
				{
					path: "platinum_contact_detail",
					element: <Protected Component={PLATINUMCONTACTDETAIL} />,
				},
				{
					path: "update_version",
					element: <Protected Component={UPDATEVERSION} />,
				},
				
			],
		},
		{
			path: "/",
			element: <LogoOnlyLayout />,
			children: [
				{ path: "login", element: <Login /> },
				{ path: "404", element: <NotFound /> },
			],
		},
		{ path: "*", element: <Navigate to="/404" replace /> },
	]);
}
