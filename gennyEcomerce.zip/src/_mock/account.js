// ----------------------------------------------------------------------

const account = {
  displayName: 'ようこそ Hiromi',
  type: '管理者',
};

export default account;
