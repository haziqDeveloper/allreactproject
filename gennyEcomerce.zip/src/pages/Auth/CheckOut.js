import React,{useState, useEffect} from 'react';
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup/dist/yup";
import DoneIcon from "@mui/icons-material/Done";
import {
	Grid,
	TextField,
	FormControl,
    MenuItem,
	InputLabel,
	Button,
	Box,
	Select,
	FormHelperText
} from "@mui/material";
import { useForm, Controller } from "react-hook-form";
import { useParams } from "react-router-dom";
import {viewDetailData} from  '../../store/services/productService';

const defaultValues = {
    fname: "",
    lname: "",
    email: "",
    mobile: "",
    address: "",
    country: "",
    city: "",
    couponcode: "",
};

const schema = yup.object().shape({
    fname: yup.string().required("First Name is required"),
	lname: yup.string().required("Last Name is requierd"),
	mobile: yup.string().required("Mobile is required"),
	email: yup.string().required("Email is required"),
	address: yup.string().required("Address is required"),
	country: yup.string().required("Country is required"),
	city: yup.string().required("City is required"),
	zipcode: yup.string().required("Zip Code is required"),
	couponcode: yup.string().required("Coupon Code is required"),
});

const showErrors = (field, valueLen, min) => {
	if (valueLen === 0) {
		return `${field} field is required`;
	} else if (valueLen > 0 && valueLen < min) {
		return `${field} must be at least ${min} characters`;
	} else {
		return "";
	}
};

function CheckOut()
{
	const routeParams = useParams();
	const [editCheckData, setEditCheckData] = useState([]);
	const [total, setTotal] = useState(0);

	const {
		control,
		handleSubmit,
		setValue,
		formState: { errors },
	} = useForm({
		mode: "onChange",
		resolver: yupResolver(schema),
	});

    useEffect(() => {
		if (routeParams.hasOwnProperty("id")) {
			viewDetailData(routeParams.id).then((r) => {
                console.log("R Checkout",r); 
                setEditCheckData(r);
			});
		}
		// setTotal();
	}, [routeParams.id]);
	
	console.log("editCheckData",editCheckData);

useEffect(() => {
  if (editCheckData && editCheckData.price) {
    const totalData = parseFloat(editCheckData.price);
    const totalDatas = totalData + 10.00;
    setTotal(totalDatas);
  }
}, [editCheckData]);



	console.log("total", total);
    const onSubmit = (paramForms) => 
    {
        console.log("paramForms",paramForms);
    }


    return(
        <>
    <div className="container-fluid">
        <div className="row bg-secondary py-2 px-xl-5">
            <div className="col-lg-6 d-none d-lg-block">
                <div className="d-inline-flex align-items-center">
                    <a className="text-dark" href="">FAQs</a>
                    <span className="text-muted px-2">|</span>
                    <a className="text-dark" href="">Help</a>
                    <span className="text-muted px-2">|</span>
                    <a className="text-dark" href="">Support</a>
                </div>
            </div>
            <div className="col-lg-6 text-center text-lg-right">
                <div className="d-inline-flex align-items-center">
                    <a className="text-dark px-2" href="">
                        <i className="fab fa-facebook-f"></i>
                    </a>
                    <a className="text-dark px-2" href="">
                        <i className="fab fa-twitter"></i>
                    </a>
                    <a className="text-dark px-2" href="">
                        <i className="fab fa-linkedin-in"></i>
                    </a>
                    <a className="text-dark px-2" href="">
                        <i className="fab fa-instagram"></i>
                    </a>
                    <a className="text-dark pl-2" href="">
                        <i className="fab fa-youtube"></i>
                    </a>
                </div>
            </div>
        </div>
        <div className="row align-items-center py-3 px-xl-5">
            <div className="col-lg-3 d-none d-lg-block">
                <a href="" className="text-decoration-none">
                    <h1 className="m-0 display-5 font-weight-semi-bold"><span className="text-primary font-weight-bold border px-3 mr-1">E</span>Shopper</h1>
                </a>
            </div>
            <div className="col-lg-6 col-6 text-left">
                <form action="">
                    <div className="input-group">
                        <input type="text" className="form-control" placeholder="Search for products"/>
                        <div className="input-group-append">
                            <span className="input-group-text bg-transparent text-primary">
                                <i className="fa fa-search"></i>
                            </span>
                        </div>
                    </div>
                </form>
            </div>
            <div className="col-lg-3 col-6 text-right">
                <a href="" className="btn border">
                    <i className="fas fa-heart text-primary"></i>
                    <span className="badge">0</span>
                </a>
                <a href="" className="btn border">
                    <i className="fas fa-shopping-cart text-primary"></i>
                    <span className="badge">0</span>
                </a>
            </div>
        </div>
    </div>

    <div className="container-fluid">
        <div className="row border-top px-xl-5">
            <div className="col-lg-3 d-none d-lg-block">
                <a className="btn shadow-none d-flex align-items-center justify-content-between bg-primary text-white w-100" data-toggle="collapse" href="#navbar-vertical" style={{"height": "65px", "marginTop": "-1px", "padding": "0 30px"}}>
                    <h6 className="m-0">Categories</h6>
                    <i className="fa fa-angle-down text-dark"></i>
                </a>
                <nav className="collapse position-absolute navbar navbar-vertical navbar-light align-items-start p-0 border border-top-0 border-bottom-0 bg-light" id="navbar-vertical" style={{"width": "calc(100% - 30px)", "zIndex": "1"}}>
                    <div className="navbar-nav w-100 overflow-hidden" style={{"height": "410px"}}>
                        <div className="nav-item dropdown">
                            <a href="#" className="nav-link" data-toggle="dropdown">Dresses <i className="fa fa-angle-down float-right mt-1"></i></a>
                            <div className="dropdown-menu position-absolute bg-secondary border-0 rounded-0 w-100 m-0">
                                <a href="" className="dropdown-item">Men's Dresses</a>
                                <a href="" className="dropdown-item">Women's Dresses</a>
                                <a href="" className="dropdown-item">Baby's Dresses</a>
                            </div>
                        </div>
                        <a href="" className="nav-item nav-link">Shirts</a>
                        <a href="" className="nav-item nav-link">Jeans</a>
                        <a href="" className="nav-item nav-link">Swimwear</a>
                        <a href="" className="nav-item nav-link">Sleepwear</a>
                        <a href="" className="nav-item nav-link">Sportswear</a>
                        <a href="" className="nav-item nav-link">Jumpsuits</a>
                        <a href="" className="nav-item nav-link">Blazers</a>
                        <a href="" className="nav-item nav-link">Jackets</a>
                        <a href="" className="nav-item nav-link">Shoes</a>
                    </div>
                </nav>
            </div>
            <div className="col-lg-9">
                <nav className="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0">
                    <a href="" className="text-decoration-none d-block d-lg-none">
                        <h1 className="m-0 display-5 font-weight-semi-bold"><span className="text-primary font-weight-bold border px-3 mr-1">E</span>Shopper</h1>
                    </a>
                    <button type="button" className="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div className="navbar-nav mr-auto py-0">
                            <a href="index.html" className="nav-item nav-link">Home</a>
                            <a href="shop.html" className="nav-item nav-link">Shop</a>
                            <a href="detail.html" className="nav-item nav-link">Shop Detail</a>
                            <div className="nav-item dropdown">
                                <a href="#" className="nav-link dropdown-toggle active" data-toggle="dropdown">Pages</a>
                                <div className="dropdown-menu rounded-0 m-0">
                                    <a href="cart.html" className="dropdown-item">Shopping Cart</a>
                                    <a href="checkout.html" className="dropdown-item">Checkout</a>
                                </div>
                            </div>
                            <a href="contact.html" className="nav-item nav-link">Contact</a>
                        </div>
                        <div className="navbar-nav ml-auto py-0">
                            <a href="" className="nav-item nav-link">Login</a>
                            <a href="" className="nav-item nav-link">Register</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>

    <div className="container-fluid bg-secondary mb-5">
        <div className="d-flex flex-column align-items-center justify-content-center" style={{"minHeight": "300px"}}>
            <h1 className="font-weight-semi-bold text-uppercase mb-3">Checkout</h1>
            <div className="d-inline-flex">
                <p className="m-0"><a href="">Home</a></p>
                <p className="m-0 px-2">-</p>
                <p className="m-0">Checkout</p>
            </div>
        </div>
    </div>


    <div className="container-fluid pt-5">
        <div className="row px-xl-5">
            <div className="col-lg-8">
                <div className="mb-4">
                    <h4 className="font-weight-semi-bold mb-4">Billing Address</h4>
                    <form onSubmit={handleSubmit(onSubmit)}>
                    <div className="row">
                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
											<FormControl fullWidth>
												<Controller
													name="fname"
													control={control}
													rules={{ required: true }}
													render={({ field: { value, onChange } }) => (
														<TextField
															value={value}
															onChange={onChange}
															label="First Name"
															placeholder="Please Enter First Name"
															error={Boolean(errors.fname)}
															aria-describedby="validation-schema-fname"
														/>
													)}
												/>
												{errors.fname && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-fname">
														{errors.fname.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>
                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
											<FormControl fullWidth>
												<Controller
													name="lname"
													control={control}
													rules={{ required: true }}
													render={({ field: { value, onChange } }) => (
														<TextField
															value={value}
															onChange={onChange}
															label="Last Name"
															placeholder="Please Enter Last Name"
															error={Boolean(errors.lname)}
															aria-describedby="validation-schema-lname"
														/>
													)}
												/>
												{errors.lname && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-lname">
														{errors.lname.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>   
                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
											<FormControl fullWidth>
												<Controller
													name="email"
													control={control}
													rules={{ required: true }}
													render={({ field: { value, onChange } }) => (
														<TextField
															value={value}
															onChange={onChange}
															label="Email"
															placeholder="Email"
															error={Boolean(errors.email)}
															aria-describedby="validation-schema-email"
														/>
													)}
												/>
												{errors.email && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-email">
														{errors.email.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>
                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
								<FormControl fullWidth>
								    <Controller
										name="mobile"
										control={control}
										rules={{ required: true }}
										render={({ field: { value, onChange } }) => (
											<TextField
											value={value}
											onChange={onChange}
											label="Mobile No"
											placeholder="+123 456 765"
											error={Boolean(errors.mobile)}
											aria-describedby="validation-schema-mobile"
														/>
													)}
												/>
												{errors.mobile && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-mobile">
														{errors.mobile.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>
                         <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
								<FormControl fullWidth>
								    <Controller
										name="address"
										control={control}
										rules={{ required: true }}
										render={({ field: { value, onChange } }) => (
											<TextField
											value={value}
											onChange={onChange}
											label="Address"
											placeholder="Please Enter Address"
											error={Boolean(errors.address)}
											aria-describedby="validation-schema-address"
														/>
													)}
												/>
												{errors.address && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-address">
														{errors.address.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>
                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
											<FormControl fullWidth>
												<InputLabel
													id="validation-basic-country"
													error={Boolean(errors.country)}
													htmlFor="validation-basic-country">
												    Country
												</InputLabel>
												<Controller
													name="country"
													control={control}
													rules={{ required: true }}
													render={({ field: { value, onChange } }) => (
														<Select
															value={value}
															label="Country"
															onChange={onChange}
															error={Boolean(errors.country)}
															labelId="validation-basic-country"
															aria-describedby="validation-basic-country">
															<MenuItem value="">Please Select A Country</MenuItem>
															<MenuItem value="Pakistan">Pakistan</MenuItem>
															<MenuItem value="USA">USA</MenuItem>
															<MenuItem value="UAE">UAE</MenuItem>
															<MenuItem value="GERMANY">Germany</MenuItem>
														</Select>
													)}
												/>
												{errors.country && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-country">
														{errors.country.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>    
                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
								<FormControl fullWidth>
								    <Controller
										name="city"
										control={control}
										rules={{ required: true }}
										render={({ field: { value, onChange } }) => (
											<TextField
											value={value}
											onChange={onChange}
											label="City"
											placeholder="Please Enter A City"
											error={Boolean(errors.city)}
											aria-describedby="validation-schema-city"
														/>
													)}
												/>
												{errors.city && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-city">
														{errors.city.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>
                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
								<FormControl fullWidth>
								    <Controller
										name="couponcode"
										control={control}
										rules={{ required: true }}
										render={({ field: { value, onChange } }) => (
											<TextField
											value={value}
											onChange={onChange}
											label="Coupon Code"
											placeholder="Please Enter Coupon Code"
											error={Boolean(errors.couponcode)}
											aria-describedby="validation-schema-couponcode"
														/>
													)}
												/>
												{errors.couponcode && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-couponcode">
														{errors.couponcode.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>

                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
								<FormControl fullWidth>
								    <Controller
										name="zipcode"
										control={control}
										rules={{ required: true }}
										render={({ field: { value, onChange } }) => (
											<TextField
											value={value}
											onChange={onChange}
											label="Zip Code"
											placeholder="Please Enter A Zip Code"
											error={Boolean(errors.zipcode)}
											aria-describedby="validation-schema-zipcode"
														/>
													)}
												/>
												{errors.zipcode && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-zipcode">
														{errors.zipcode.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>

                        <Button
							variant="contained"
							type="submit"
							className="SaveButton"
							startIcon={<DoneIcon />}>
							Submit
						</Button>
                       
                    </div>
                        </form>
                </div>

            </div>
            <div className="col-lg-4">
                <div className="card border-secondary mb-5">
                    <div className="card-header bg-secondary border-0">
                        <h4 className="font-weight-semi-bold m-0">Order Total</h4>
                    </div>
                    <div className="card-body">
                        <h5 className="font-weight-medium mb-3">Products</h5>
                        <div className="d-flex justify-content-between">
                            <p>Colorful Stylish Shirt 1</p>
                            <p>$150</p>
                        </div>
                        <div className="d-flex justify-content-between">
                            <p>Colorful Stylish Shirt 2</p>
                            <p>$150</p>
                        </div>
                        <div className="d-flex justify-content-between">
                            <p>Colorful Stylish Shirt 3</p>
                            <p>$150</p>
                        </div>
                        <hr className="mt-0"/>
                        <div className="d-flex justify-content-between mb-3 pt-1">
                            <h6 className="font-weight-medium">Subtotal</h6>
                            <h6 className="font-weight-medium">$150</h6>
                        </div>
                        <div className="d-flex justify-content-between">
                            <h6 className="font-weight-medium">Shipping</h6>
                            <h6 className="font-weight-medium">$10</h6>
                        </div>
                    </div>
                    <div className="card-footer border-secondary bg-transparent">
                        <div className="d-flex justify-content-between mt-2">
                            <h5 className="font-weight-bold">Total</h5>
                            <h5 className="font-weight-bold">${total.toFixed(2)}</h5>
                        </div>
                    </div>
                </div>
                <div className="card border-secondary mb-5">
                    <div className="card-header bg-secondary border-0">
                        <h4 className="font-weight-semi-bold m-0">Payment</h4>
                    </div>
                    <div className="card-body">
                        <div className="form-group">
                            <div className="custom-control custom-radio">
                                <input type="radio" className="custom-control-input" name="payment" id="paypal"/>
                                <label className="custom-control-label" htmlFor="paypal">Paypal</label>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="custom-control custom-radio">
                                <input type="radio" className="custom-control-input" name="payment" id="directcheck"/>
                                <label className="custom-control-label" htmlFor="directcheck">Direct Check</label>
                            </div>
                        </div>
                        <div className="">
                            <div className="custom-control custom-radio">
                                <input type="radio" className="custom-control-input" name="payment" id="banktransfer"/>
                                <label className="custom-control-label" htmlFor="banktransfer">Bank Transfer</label>
                            </div>
                        </div>
                    </div>
                    <div className="card-footer border-secondary bg-transparent">
                        <button className="btn btn-lg btn-block btn-primary font-weight-bold my-3 py-3">Place Order</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

        </>
    )
}
export default CheckOut