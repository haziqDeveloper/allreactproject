import { getTrendyProductAPI,editDetailDateApi,editCategoryDetailDateApi } from "../api";
import Instance from "../axois";

const API_URL = process.env.REACT_APP_API;


const getTrendyProduct = async () => {
    try {
        const response = await Instance.get(API_URL + getTrendyProductAPI);
        return response.data;
    } catch (error) {
        // console.log("New Test", error);
    }
}

const viewDetailData = async (id) => {
	try {
		  const response = await Instance.get(API_URL + editDetailDateApi +"/"+ id);
		  return response.data;
	  } catch (error) {
		  throw error;
	  }
  };

const viewCategoryDetailData = async (id) => {
	try {
		  const response = await Instance.get(API_URL + editCategoryDetailDateApi +"/"+ id);
		  return response.data;
	  } catch (error) {
		  throw error;
	  }
  };


export {getTrendyProduct,viewDetailData, viewCategoryDetailData};