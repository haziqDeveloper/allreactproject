import React,{useState, useEffect} from 'react';
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup/dist/yup";
import DoneIcon from "@mui/icons-material/Done";
import toast from "react-hot-toast";
import {
	Grid,
	TextField,
	FormControl,
    MenuItem,
	InputLabel,
	Button,
	Box,
	Select,
	FormHelperText
} from "@mui/material";
import { useForm, Controller } from "react-hook-form";
import { useParams,useNavigate } from "react-router-dom";
import {viewDetailData,postCheckout} from  '../../store/services/productService';
import Header from '../Template/Header';

const defaultValues = {
    name: "",
    lname: "",
    email: "",
    mobile: "",
    address: "",
    country: "",
    city: "",
    couponcode: "",
};

const schema = yup.object().shape({
    name: yup.string().required("First Name is required"),
	lname: yup.string().required("Last Name is requierd"),
	mobile: yup.string().required("Mobile is required"),
	email: yup.string().required("Email is required"),
	address: yup.string().required("Address is required"),
	country: yup.string().required("Country is required"),
	city: yup.string().required("City is required"),
	zipcode: yup.string().required("Zip Code is required"),
	couponcode: yup.string().required("Coupon Code is required"),
});

const showErrors = (field, valueLen, min) => {
	if (valueLen === 0) {
		return `${field} field is required`;
	} else if (valueLen > 0 && valueLen < min) {
		return `${field} must be at least ${min} characters`;
	} else {
		return "";
	}
};

function CheckOut()
{
	const routeParams = useParams();
	const navigate = useNavigate();
	const [editCheckData, setEditCheckData] = useState([]);
	const [total, setTotal] = useState(0);

	const {
		control,
		handleSubmit,
		setValue,
		formState: { errors },
	} = useForm({
		mode: "onChange",
		resolver: yupResolver(schema),
	});

    useEffect(() => {
		if (routeParams.hasOwnProperty("id")) {
			viewDetailData(routeParams.id).then((r) => {
                console.log("R Checkout",r); 
                setEditCheckData(r);
			});
		}
		// setTotal();
	}, [routeParams.id]);
	
	console.log("editCheckData",editCheckData);

useEffect(() => {
  if (editCheckData && editCheckData.price) {
    const totalData = parseFloat(editCheckData.price);
    const totalDatas = totalData + 10.00;
    setTotal(totalDatas);
  }
}, [editCheckData]);


    const onSubmit = (paramForms) => 
    {
		const product_id = editCheckData.id;
		const product_type = editCheckData.type;
		paramForms.product_id = product_id;
		paramForms.product_type = product_type;
		console.log("postid",paramForms);
		postCheckout(paramForms)
		.then((r) => {
			console.log("R",r)
			toast.success("Data Is Successfull!");
			setTimeout(() => {
				navigate(`/order-confirm/${product_id}`);
			},5000)
		})
		.catch((error) => {console.log("error",error)});
    }


    return(
        <>
    
    <Header/>

    <div className="container-fluid bg-secondary mb-5">
        <div className="d-flex flex-column align-items-center justify-content-center" style={{"minHeight": "300px"}}>
            <h1 className="font-weight-semi-bold text-uppercase mb-3">Checkout</h1>
            <div className="d-inline-flex">
                <p className="m-0"><a href="">Home</a></p>
                <p className="m-0 px-2">-</p>
                <p className="m-0">Checkout</p>
            </div>
        </div>
    </div>


    <div className="container-fluid pt-5">
        <div className="row px-xl-5">
            <div className="col-lg-8">
                <div className="mb-4">
                    <h4 className="font-weight-semi-bold mb-4">Billing Address</h4>
                    <form onSubmit={handleSubmit(onSubmit)}>
                    <div className="row">
                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
											<FormControl fullWidth>
												<Controller
													name="name"
													control={control}
													rules={{ required: true }}
													render={({ field: { value, onChange } }) => (
														<TextField
															value={value}
															onChange={onChange}
															label="First Name"
															placeholder="Please Enter First Name"
															error={Boolean(errors.name)}
															aria-describedby="validation-schema-name"
														/>
													)}
												/>
												{errors.name && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-name">
														{errors.name.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>
                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
											<FormControl fullWidth>
												<Controller
													name="lname"
													control={control}
													rules={{ required: true }}
													render={({ field: { value, onChange } }) => (
														<TextField
															value={value}
															onChange={onChange}
															label="Last Name"
															placeholder="Please Enter Last Name"
															error={Boolean(errors.lname)}
															aria-describedby="validation-schema-lname"
														/>
													)}
												/>
												{errors.lname && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-lname">
														{errors.lname.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>   
                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
											<FormControl fullWidth>
												<Controller
													name="email"
													control={control}
													rules={{ required: true }}
													render={({ field: { value, onChange } }) => (
														<TextField
															value={value}
															onChange={onChange}
															label="Email"
															placeholder="Email"
															error={Boolean(errors.email)}
															aria-describedby="validation-schema-email"
														/>
													)}
												/>
												{errors.email && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-email">
														{errors.email.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>
                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
								<FormControl fullWidth>
								    <Controller
										name="mobile"
										control={control}
										rules={{ required: true }}
										render={({ field: { value, onChange } }) => (
											<TextField
											value={value}
											onChange={onChange}
											label="Mobile No"
											placeholder="+123 456 765"
											error={Boolean(errors.mobile)}
											aria-describedby="validation-schema-mobile"
														/>
													)}
												/>
												{errors.mobile && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-mobile">
														{errors.mobile.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>
                         <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
								<FormControl fullWidth>
								    <Controller
										name="address"
										control={control}
										rules={{ required: true }}
										render={({ field: { value, onChange } }) => (
											<TextField
											value={value}
											onChange={onChange}
											label="Address"
											placeholder="Please Enter Address"
											error={Boolean(errors.address)}
											aria-describedby="validation-schema-address"
														/>
													)}
												/>
												{errors.address && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-address">
														{errors.address.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>
                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
											<FormControl fullWidth>
												<InputLabel
													id="validation-basic-country"
													error={Boolean(errors.country)}
													htmlFor="validation-basic-country">
												    Country
												</InputLabel>
												<Controller
													name="country"
													control={control}
													rules={{ required: true }}
													render={({ field: { value, onChange } }) => (
														<Select
															value={value}
															label="Country"
															onChange={onChange}
															error={Boolean(errors.country)}
															labelId="validation-basic-country"
															aria-describedby="validation-basic-country">
															<MenuItem value="">Please Select A Country</MenuItem>
															<MenuItem value="Pakistan">Pakistan</MenuItem>
															<MenuItem value="USA">USA</MenuItem>
															<MenuItem value="UAE">UAE</MenuItem>
															<MenuItem value="GERMANY">Germany</MenuItem>
														</Select>
													)}
												/>
												{errors.country && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-country">
														{errors.country.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>    
                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
								<FormControl fullWidth>
								    <Controller
										name="city"
										control={control}
										rules={{ required: true }}
										render={({ field: { value, onChange } }) => (
											<TextField
											value={value}
											onChange={onChange}
											label="City"
											placeholder="Please Enter A City"
											error={Boolean(errors.city)}
											aria-describedby="validation-schema-city"
														/>
													)}
												/>
												{errors.city && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-city">
														{errors.city.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>
                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
								<FormControl fullWidth>
								    <Controller
										name="couponcode"
										control={control}
										rules={{ required: true }}
										render={({ field: { value, onChange } }) => (
											<TextField
											value={value}
											onChange={onChange}
											label="Coupon Code"
											placeholder="Please Enter Coupon Code"
											error={Boolean(errors.couponcode)}
											aria-describedby="validation-schema-couponcode"
														/>
													)}
												/>
												{errors.couponcode && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-couponcode">
														{errors.couponcode.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>

                        <div className="col-md-6 form-group">
                        <Box className="BoxWidth">
								<FormControl fullWidth>
								    <Controller
										name="zipcode"
										control={control}
										rules={{ required: true }}
										render={({ field: { value, onChange } }) => (
											<TextField
											value={value}
											onChange={onChange}
											label="Zip Code"
											placeholder="Please Enter A Zip Code"
											error={Boolean(errors.zipcode)}
											aria-describedby="validation-schema-zipcode"
														/>
													)}
												/>
												{errors.zipcode && (
													<FormHelperText
														sx={{ color: "error.main" }}
														id="validation-schema-zipcode">
														{errors.zipcode.message}
													</FormHelperText>
												)}
											</FormControl>
										</Box>
                        </div>

                        <Button
							variant="contained"
							type="submit"
							className="SaveButton"
							startIcon={<DoneIcon />}>
							Submit
						</Button>
                       
                    </div>
                        </form>
                </div>

            </div>
            <div className="col-lg-4">
                <div className="card border-secondary mb-5">
                    <div className="card-header bg-secondary border-0">
                        <h4 className="font-weight-semi-bold m-0">Order Total</h4>
                    </div>
                    <div className="card-body">
                        <h5 className="font-weight-medium mb-3">Products</h5>
                        <div className="d-flex justify-content-between">
                            <p>Colorful Stylish Shirt 1</p>
                            <p>$150</p>
                        </div>
                        <div className="d-flex justify-content-between">
                            <p>Colorful Stylish Shirt 2</p>
                            <p>$150</p>
                        </div>
                        <div className="d-flex justify-content-between">
                            <p>Colorful Stylish Shirt 3</p>
                            <p>$150</p>
                        </div>
                        <hr className="mt-0"/>
                        <div className="d-flex justify-content-between mb-3 pt-1">
                            <h6 className="font-weight-medium">Subtotal</h6>
                            <h6 className="font-weight-medium">$150</h6>
                        </div>
                        <div className="d-flex justify-content-between">
                            <h6 className="font-weight-medium">Shipping</h6>
                            <h6 className="font-weight-medium">$10</h6>
                        </div>
                    </div>
                    <div className="card-footer border-secondary bg-transparent">
                        <div className="d-flex justify-content-between mt-2">
                            <h5 className="font-weight-bold">Total</h5>
                            <h5 className="font-weight-bold">${total.toFixed(2)}</h5>
                        </div>
                    </div>
                </div>
                <div className="card border-secondary mb-5">
                    <div className="card-header bg-secondary border-0">
                        <h4 className="font-weight-semi-bold m-0">Payment</h4>
                    </div>
                    <div className="card-body">
                        <div className="form-group">
                            <div className="custom-control custom-radio">
                                <input type="radio" className="custom-control-input" name="payment" id="paypal"/>
                                <label className="custom-control-label" htmlFor="paypal">Paypal</label>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="custom-control custom-radio">
                                <input type="radio" className="custom-control-input" name="payment" id="directcheck"/>
                                <label className="custom-control-label" htmlFor="directcheck">Direct Check</label>
                            </div>
                        </div>
                        <div className="">
                            <div className="custom-control custom-radio">
                                <input type="radio" className="custom-control-input" name="payment" id="banktransfer"/>
                                <label className="custom-control-label" htmlFor="banktransfer">Bank Transfer</label>
                            </div>
                        </div>
                    </div>
                    <div className="card-footer border-secondary bg-transparent">
                        <button className="btn btn-lg btn-block btn-primary font-weight-bold my-3 py-3">Place Order</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

        </>
    )
}
export default CheckOut