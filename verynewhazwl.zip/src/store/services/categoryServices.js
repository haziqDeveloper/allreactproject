import { getCategoryAPI,editRelatedCategoryDateApi } from "../api";
import Instance from "../axois";

const API_URL = process.env.REACT_APP_API;


const getCategory = async () => {
    try {
        const response = await Instance.get(API_URL + getCategoryAPI);
        return response.data;
    } catch (error) {
        // console.log("New Test", error);
    }
}

const editRelatedCategory = async (id) => {
	try {
		  const response = await Instance.get(API_URL + editRelatedCategoryDateApi +"/"+ id);
		  return response.data;
	  } catch (error) {
		  throw error;
	  }
  };





export {getCategory,editRelatedCategory};