import React from 'react'
import bannerOne from '../../assets/images/bannerDiscount/bn4.png';
import bannerTwo from '../../assets/images/bannerDiscount/bn6.png';


function AnimatedBanner()
{
  return (
    <>
<div className="container-fluid pt-5">   
    <div class="row px-xl-5 pb-3">
      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12">
        <div class="img-ban">
          <img src={bannerOne} alt="img-center-banner" class="img-responsive"/>
        </div>
      </div>
      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12">
        <div class="article-container">
          <div class="article-img-holder"></div>
      </div>
      </div>
      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12">
        <div class="img-ban">
          <img src={bannerTwo} alt="img-center-banner" class="img-responsive"/>
        </div>
      </div>
    </div>
</div> 
    </>
  )
}
export default AnimatedBanner