import React,{useState, useEffect} from 'react';
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup/dist/yup";
import DoneIcon from "@mui/icons-material/Done";
import toast from "react-hot-toast";
import {
	Grid,
	TextField,
	FormControl,
    MenuItem,
	InputLabel,
	Button,
	Box,
	Select,
	FormHelperText
} from "@mui/material";
import { useForm, Controller } from "react-hook-form";
import { useParams,useNavigate } from "react-router-dom";
import {viewCheckoutData} from  '../../store/services/productService';
import Header from '../Template/Header';
import CASHDELIVERY from '../../assets/images/cash-on-delivery.png'


const defaultValues = {
    fname: "",
    lname: "",
    email: "",
    mobile: "",
    address: "",
    country: "",
    city: "",
    couponcode: "",
};

const schema = yup.object().shape({
    fname: yup.string().required("First Name is required"),
	lname: yup.string().required("Last Name is requierd"),
	mobile: yup.string().required("Mobile is required"),
	email: yup.string().required("Email is required"),
	address: yup.string().required("Address is required"),
	country: yup.string().required("Country is required"),
	city: yup.string().required("City is required"),
	zipcode: yup.string().required("Zip Code is required"),
	couponcode: yup.string().required("Coupon Code is required"),
});

const showErrors = (field, valueLen, min) => {
	if (valueLen === 0) {
		return `${field} field is required`;
	} else if (valueLen > 0 && valueLen < min) {
		return `${field} must be at least ${min} characters`;
	} else {
		return "";
	}
};

function ConfirmOrder()
{
	const routeParams = useParams();
	const navigate = useNavigate();
	const [editCheckData, setEditCheckData] = useState([]);
	const [total, setTotal] = useState(0);

	const {
		control,
		handleSubmit,
		setValue,
		formState: { errors },
	} = useForm({
		mode: "onChange",
		resolver: yupResolver(schema),
	});

    useEffect(() => {
		if (routeParams.hasOwnProperty("id")) {
			viewCheckoutData(routeParams.id).then((r) => {
                console.log("R Confirm",r); 
                setEditCheckData(r);
			});
		}
		// setTotal();
	}, [routeParams.id]);
	
	console.log("editCheckData",editCheckData);

useEffect(() => {
  if (editCheckData && editCheckData.price) {
    const totalData = parseFloat(editCheckData.price);
    const totalDatas = totalData + 10.00;
    setTotal(totalDatas);
  }
}, [editCheckData]);

    return(
        <>
    
    <Header/>

    <div className="container-fluid bg-secondary mb-5">
        <div className="d-flex flex-column align-items-center justify-content-center" style={{"minHeight": "300px"}}>
            <h1 className="font-weight-semi-bold text-uppercase mb-3">Confirm Order</h1>
            <div className="d-inline-flex">
                <p className="m-0"><a href="">Home</a></p>
                <p className="m-0 px-2">-</p>
                <p className="m-0">Order</p>
            </div>
        </div>
    </div>


    <div class="container-fluid pt-5">
        <div class="row px-xl-5">
            <div class="col-lg-8 table-responsive mb-5">
                

                <div class="">
                    <h3>Delivery</h3>
                    <div className="haz_cash_delivery">
                         <h4>Cash <img src={CASHDELIVERY} alt="delivery_img"/> Delivery</h4>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card border-secondary mb-5">
                    <div class="card-header bg-secondary border-0">
                        <h4 class="font-weight-semi-bold m-0">Cart Summary</h4>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-3 pt-1">
                            <h6 class="font-weight-medium">Subtotal</h6>
                            <h6 class="font-weight-medium">$150</h6>
                        </div>
                        <div class="d-flex justify-content-between">
                            <h6 class="font-weight-medium">Shipping</h6>
                            <h6 class="font-weight-medium">$10</h6>
                        </div>
                    </div>
                    <div class="card-footer border-secondary bg-transparent">
                        <div class="d-flex justify-content-between mt-2">
                            <h5 class="font-weight-bold">Total</h5>
                            <h5 class="font-weight-bold">$160</h5>
                        </div>
                        <button class="btn btn-block btn-primary my-3 py-3">Proceed To Checkout</button>
                    </div>
                </div>
            </div>
        </div>
    </div>


        </>
    )
}
export default ConfirmOrder