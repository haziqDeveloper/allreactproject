import { getTrendyProductAPI,PostCheckoutApi,GetCheckoutApi,editDetailDateApi,editCategoryDetailDateApi,getLatestProductDataAPI,getSeasonProductAPI } from "../api";
import Instance from "../axois";

const API_URL = process.env.REACT_APP_API;


const getTrendyProduct = async () => {
    try {
        const response = await Instance.get(API_URL + getTrendyProductAPI);
        return response.data;
    } catch (error) {
        // console.log("New Test", error);
    }
}


const getSeasonProduct = async () => {
    try {
        const response = await Instance.get(API_URL + getSeasonProductAPI);
        return response.data;
    } catch (error) {
        // console.log("New Test", error);
    }
}


const getLatestProduct = async () => {
    try {
        const response = await Instance.get(API_URL + getLatestProductDataAPI);
        return response.data;
    } catch (error) {
        // console.log("New Test", error);
    }
}

const postCheckout = async (data) => {
	try {
		  const response = await Instance.post(API_URL + PostCheckoutApi , data);
		  return response.data;
	  } catch (error) {
		  throw error;
	  }
  };

 const viewCheckoutData = async (id) => {
	try {
		  const response = await Instance.get(API_URL + GetCheckoutApi +"/"+ id);
		  return response.data;
	  } catch (error) {
		  throw error;
	  }
  };


const viewDetailData = async (id) => {
	try {
		  const response = await Instance.get(API_URL + editDetailDateApi +"/"+ id);
		  return response.data;
	  } catch (error) {
		  throw error;
	  }
  };

const viewCategoryDetailData = async (id) => {
	try {
		  const response = await Instance.get(API_URL + editCategoryDetailDateApi +"/"+ id);
		  return response.data;
	  } catch (error) {
		  throw error;
	  }
  };


export {getTrendyProduct,viewDetailData,viewCheckoutData,postCheckout, viewCategoryDetailData,getLatestProduct,getSeasonProduct};