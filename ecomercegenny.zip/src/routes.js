/** @format */

import { Navigate, useRoutes } from "react-router-dom";
// layouts
import DashboardLayout from "./layouts/dashboard";
import LogoOnlyLayout from "./layouts/LogoOnlyLayout";
//
import Login from "./pages/Auth/Login";
import DetailPage from "./pages/Auth/DetailPage";
import CategoryDetailPage from "./pages/Auth/CategoryDetailPage";
import CheckOut from "./pages/Auth/CheckOut";

import Category from "./pages/Category/Category";
import RelatedCategory from "./pages/Category/RelatedCategory";

// Role CRUD
import NotFound from "./pages/Page404";
import Protected from "./components/Protected";


// ----------------------------------------------------------------------

export default function Router() {
	return useRoutes([
		{
			path: "/",
			element: <Login />,
		},
		{
			path: "/",
			element: <Protected Component={Login} />,
		},
		{
			path: "/",
			// element: <DashboardLayout />,
			children: [
				{ path: "category", element: <Protected Component={Category} /> },

				{ path: "related-category-page/:id", element: <Protected Component={RelatedCategory} /> },

				{ path: "detail-page/:id", element: <Protected Component={DetailPage} /> },

				{ path: "category-detail-page/:id", element: <Protected Component={CategoryDetailPage} /> },

				{ path: "checkout/:id", element: <Protected Component={CheckOut} /> },
			
				
			],
		},
		{
			path: "/",
			element: <LogoOnlyLayout />,
			children: [
				{ path: "login", element: <Login /> },
				{ path: "404", element: <NotFound /> },
			],
		},
		{ path: "*", element: <Navigate to="/404" replace /> },
	]);
}
