import React,{useState, useEffect} from 'react'
import { getCategory } from '../../store/services/categoryServices'
import { useNavigate } from "react-router-dom";

function Category()
{
    const navigate = useNavigate();
    const [category, setCategory] = useState([]);

    useEffect(() => {
       getCategory()
       .then(r => {
           console.log("R Cte",r)
           setCategory(r);
        })
       .catch((error) => {console.log("Error",error)})
    },[])

    const editCategory = (id) =>
    {
       console.log("ID",id);
       navigate(`/related-category-page/${id}`);
    }


    return(
        <>
    <div className="container-fluid pt-5">
        <div className="text-center mb-4">
            <h2 className="section-title px-5"><span className="px-2">Just Categories</span></h2>
        </div>
        <div className="row px-xl-5 pb-3">
            {
                category.map((item) => {
                    return(
                        <div className="col-lg-2 col-md-4 col-sm-12 pb-1">
                           <div className="genny_categories">
                             <div className="wo-category" onClick={() => {editCategory(item.id)}}>
                                <img className="img-fluid w-100" src={item.object} alt="category-img"/>
                            </div>
                            <h4>{item.title}</h4>
                        </div>
                    </div>
                    )
                })
            }
        </div>
    </div>        
        </>
    )
}
export default Category