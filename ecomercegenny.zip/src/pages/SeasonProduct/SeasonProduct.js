import React,{useEffect,useState} from 'react'
import { getSeasonProduct } from '../../store/services/productService'

function SeasonProduct()
{

  const [seasonData,setSeasonData] = useState([]);
  
  useEffect(() => {
    getSeasonData();
  },[])

  const getSeasonData = () => {
    getSeasonProduct()
    .then((r) => {console.log("R Season",r)
        setSeasonData(r);
     })
    .catch((error) => {console.log("Error",error)})
  }
  return(
     <>
         <div className="container-fluid pt-5">
         <div className="text-center mb-4">
            <h2 className="section-title px-5"><span className="px-2">Winter Season Product</span></h2>
        </div>
        <div className="row px-xl-5 pb-3">
            {
                seasonData.map((item) => {
                    return(
                        <>
                        <div className="col-lg-3 col-md-6 pb-1">
                            <div className="cat-item d-flex flex-column border mb-4" style={{"padding": "30px"}}>
                                <p className="text-left">Price:{item.price}</p>
                                <a href="" className="cat-img position-relative overflow-hidden mb-3">
                                    <img className="img-fluid" src={item.object} alt=""/>
                                </a>
                                <h5 className="font-weight-semi-bold m-0">{item.title}</h5>
                            </div>
                        </div>
                        </>
                    )
                })
            }
        </div>
    </div>
     </>
  )
}
export default SeasonProduct