import React,{Component} from 'react';
import axios from 'axios';
import toast from "react-hot-toast";
import {
	Grid,
	Card,
    Box,
    Button,
    FormControl,
	CardHeader, 
} from "@mui/material";
import Page from "../../components/Page";
import TextField from '@mui/material/TextField';
import DoneIcon from "@mui/icons-material/Done";
import FileUpload from '../../components/FileUpload'
import { deleteFile } from '../../store/services/platinumServices'
import CROSS from '../../assets/images/delete.png'

class DomainUrl extends Component
{
    state = {
      panels:[],
      isLoaded:true,
      app_url:'',
      app_logo:'',
      loading:false,
      error_list:[],
    }
    handleInput = (e) => {
      this.setState({
           [e.target.name]: e.target.value
      });
    }


    async componentDidMount() {
      const resp = await axios.get('https://gennycamp.com/genny/api/kingPlatinum/domain_Url');
      console.log("Original",resp.data);
      const responde = resp.data
    //   this.setState({panels:responde})
      console.log("zonlu",responde.app_url)
      this.setState({app_url:responde.app_url,app_logo:responde.app_logo});
    }

    updatePanels = async (e) => {
        e.preventDefault();
        let param = {
          app_url: this.state.app_url,
          app_logo: this.state.app_logo,
        }
        const formData = new FormData();
        Object.keys(param).map(p => {
          formData.append(p,this.state[p]);
        })
        formData.append('_method','put');
        formData.append('id',1);
        // const formData = new FormData();
        // formData.append("file", this.state.file);
        // console.log("ji para,",param);
        const id = 1;
          const res = await axios.post(`https://gennycamp.com/genny/api/kingPlatinum/domainUrl/${id}`, formData);
          console.log("submit the data",res);
          if(res.data.status === 200)
        {
            toast.success("Update App Info is Successfully!");
        }
        else if(res.data.status === 400)
        {
               this.setState({
                ...this.state,
                   error_list:res.data.errors
               })
        }
  
  
        

  }

  handleUpload = (e) => {
    console.log("Imageestion",e);
    this.setState({
      ...this.state,
         app_logo: e
  })
}

removeImage = () => {
  let params =
  {
      app_logo: ""
  }
  const id = 1;
  deleteFile(id, params)
  .then(r => {
      console.log("R",r);
      toast.success("Delete This Image");
      window.location.reload();
  })
  .catch((error) => {console.log("Error",error)})
}


  
   render()
   {
    
    return(
     <>
		<Page className="User Overview" title="King Platinum Contact Detail">
            <Grid container spacing={2}>
					<Grid item xs={12}>
                    <Card className="RoleCard">
						<CardHeader title="King Platinum Contact Detail" className="RolePageHeading" />
                        <Grid container spacing={2} className="RoleCardBody">
							<Grid item xs={12}>
        
                     <form onSubmit={this.updatePanels}>
                     <Box className="BoxWidth">
                     <TextField id='outlined-basic' 
                        name="app_url" 
                        onChange={this.handleInput}
                        value={this.state.app_url}
                        label='App Url' />
                     </Box>

                     <Box className="BoxWidth ht-manage">
											<FormControl>
												<FileUpload img={this.state.app_logo} onChange={this.handleUpload}/>
                        <img src={CROSS} className="crossImage" onClick={this.removeImage} alt=""/>
											</FormControl>
										</Box>

                     <Button
						variant="contained"
					    type="submit"
						className="SaveButton"
						startIcon={<DoneIcon />}>
						Update App Info
					</Button>
                    </form>
           			
									</Grid>
								</Grid>
                    </Card>            
                    </Grid>
            </Grid>            
        </Page>

      </>
       );
   }
}
export default DomainUrl;