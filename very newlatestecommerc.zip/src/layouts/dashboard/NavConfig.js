/** @format */

// component
import Iconify from "../../components/Iconify";
import Homeimg from "../../assets/images/home.svg";
import Productimg from "../../assets/images/products.svg";
import Rollimg from "../../assets/images/roll.svg";


// ----------------------------------------------------------------------

const getIcon = (name) => <img src={name} alt="a" />;

const navConfig = [
	{
		title: "King Max"
	},
	{
		title: "Device Info",
		icon: getIcon(Rollimg),
		children: [
			{
				title: "Device Info",
				path: "/device-info",
			},
		],
	},
	{
		title: "App Info",
		icon: getIcon(Productimg),
		children: [
			{
				title: "App Info",
				path: "/app_info",
			},
		],
	},
	{
		title: "Contact Detail",
		icon: getIcon(Productimg),
		children: [
			{
				title: "Contact Detail",
				path: "/contact_detail",
			},
		],
	},
	{
		title: "King Platinum"
	},
	{
		title: "Device Info",
		icon: getIcon(Rollimg),
		children: [
			{
				title: "Device Info",
				path: "/platinum-device-info",
			},
		],
	},
	{
		title: "App Info",
		icon: getIcon(Productimg),
		children: [
			{
				title: "App Info",
				path: "/platinum_app_info",
			},
		],
	},
	{
		title: "Contact Detail",
		icon: getIcon(Productimg),
		children: [
			{
				title: "Contact Detail",
				path: "/platinum_contact_detail",
			},
		],
	},
];

export default navConfig;
