import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function Protected(props) {
  const navigate = useNavigate();
  const { Component } = props;
  let login = localStorage.getItem('token');
  useEffect(() => {
    if (!login) {
      navigate('/');
    }
  },[]);
  return (
    <>
      <Component />
    </>
  );
}
export default Protected;
